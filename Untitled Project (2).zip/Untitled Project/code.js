var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["d3d2030c-24f0-4f2b-82fa-0b67dede235e","9db10607-3ce7-48df-8a2e-ec006a9e5bab"],"propsByKey":{"d3d2030c-24f0-4f2b-82fa-0b67dede235e":{"name":"niñocarrera","categories":["people"],"frameCount":1,"frameSize":{"x":202,"y":400},"looping":true,"frameDelay":2,"jsonLastModified":"2021-01-15 21:43:27 UTC","pngLastModified":"2021-01-15 21:43:28 UTC","version":".A6A6RZ5yBM2i1QZzZqL7.Qj74OSUzgj","sourceUrl":"assets/api/v1/animation-library/gamelab/.A6A6RZ5yBM2i1QZzZqL7.Qj74OSUzgj/category_people/teal_shirt.png","sourceSize":{"x":202,"y":400},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/.A6A6RZ5yBM2i1QZzZqL7.Qj74OSUzgj/category_people/teal_shirt.png"},"9db10607-3ce7-48df-8a2e-ec006a9e5bab":{"name":"niña","categories":["people"],"frameCount":1,"frameSize":{"x":202,"y":400},"looping":true,"frameDelay":2,"jsonLastModified":"2021-01-15 21:43:25 UTC","pngLastModified":"2021-01-15 21:43:25 UTC","version":"ghsQyb9RIP7KnsBQhdR_.5wmUDPil6tA","sourceUrl":"assets/api/v1/animation-library/gamelab/ghsQyb9RIP7KnsBQhdR_.5wmUDPil6tA/category_people/yellow_shirt2.png","sourceSize":{"x":202,"y":400},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/ghsQyb9RIP7KnsBQhdR_.5wmUDPil6tA/category_people/yellow_shirt2.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

background("purple");



var niño = createSprite(300, 200);
  niño.setAnimation("niñocarrera");
  niño.scale=0.4;
  
  
  var niño2 = createSprite(100, 200);
  niño2.setAnimation("niña");
  niño2.scale=0.4;
  
 
 
 
 drawSprites()
 
 
 drawnet();
function drawnet()
{  
  for(var num=0;num<400;num=num+20)
  {
    line(200,num,200,num+10);
  }
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
